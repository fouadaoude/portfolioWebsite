# JavaProjects
My Own Personal Java Projects For Fun
