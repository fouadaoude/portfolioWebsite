<?php

/**
 * @file
 * config-sample.php
 *
 * Copy this file to config.php and update the database information.
 *
 * Do not store real information in this sample file.
 */

define('DB_HOST','hostname');
define('DB_USER','username');
define('DB_PASS','password');
define('DB_NAME','best_pet');
