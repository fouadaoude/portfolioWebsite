import PyInstaller.__main__
import sys, os


PyInstaller.__main__.run([  
     'app.py',
     '--onefile',
     '--windowed',
     '--hidden-import=sqlite3',
     '--add-data=database/database.db:.',
     '--add-data=txt_files/names.txt:.',
     '--add-data=txt_files/positions.txt:.',
])